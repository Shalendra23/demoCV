A Pen created at CodePen.io. You can find this one at https://codepen.io/suez/pen/JoWKKX.

 Original concept http://codyhouse.co/gem/3d-curtain-template/